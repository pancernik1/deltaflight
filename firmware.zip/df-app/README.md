# ΔF — Electron App

Dark tabbed interface with a C# debug terminal parser.

## Project structure

```
df-app/
├── main.js               # Electron main process
├── preload.js            # Context bridge (window controls)
├── package.json
├── src/
│   ├── index.html        # Full app UI
│   ├── DebugParser.cs    # C# HTTP command parser (port 5050)
│   └── DebugParser.csproj
└── parser-bin/           # Created by `npm run build:parser`
```

## Quick start

### 1. Install Node dependencies
```bash
npm install
```

### 2. Build the C# parser (requires .NET 8 SDK)
```bash
# Linux
npm run build:parser

# Windows
npm run build:parser:win

# macOS
npm run build:parser:mac
```
This compiles a **self-contained single-file binary** into `parser-bin/` —
no .NET runtime needed on the target machine after this step.

### 3. Run
```bash
npm start
```

> **No binary?** If you skip step 2, `main.js` automatically falls back to
> `dotnet run` so the debug terminal still works during development.

## Wayland / Hyprland (Linux)

The app sets Ozone flags automatically in `main.js` at startup:
```js
app.commandLine.appendSwitch("ozone-platform", "wayland");
app.commandLine.appendSwitch("enable-features", "UseOzonePlatform,WaylandWindowDecorations");
app.commandLine.appendSwitch("enable-features", "WaylandFractionalScaleV1");
```
No extra CLI flags needed — just `npm start`. If you still see blurriness,
set this in your environment before launching:
```bash
ELECTRON_OZONE_PLATFORM_HINT=wayland npm start
```

## Terminal commands (Debug tab)

| Command       | Response                     |
|---------------|------------------------------|
| `debug`       | Hello World                  |
| `help`        | Lists available commands     |
| `ping`        | Pong.                        |
| `time`        | Current server timestamp     |
| `echo <text>` | Echoes the text back         |
| `clear`       | Clears the terminal          |

Add more in `src/DebugParser.cs` inside the `ParseCommand` switch.

## Build a distributable
```bash
npm run pack   # outputs to dist/
```
